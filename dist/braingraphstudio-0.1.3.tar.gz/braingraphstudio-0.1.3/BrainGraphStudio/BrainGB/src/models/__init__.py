from .gat import GAT
from .gcn import GCN
from .mlp import MLP
from .brainnn import BrainNN
